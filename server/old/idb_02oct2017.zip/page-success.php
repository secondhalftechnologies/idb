<?php
	include("includes/db_con.php");
?>
<!DOCTYPE html>
<html>
<head>
<!-- Meta -->
      	<meta charset="utf-8">
      	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
      	<meta name="description" content="">
      	<meta name="author" content="">
        <meta name="keywords" content="">
        <meta name="robots" content="all">

        <title>Successfull Registration</title>

		<?php include('st-head.php'); ?>
        <?php include('st-validator-css.php'); ?>

</head>

<body>
	<div class="wrapper">
    	<?php  include('st-header.php'); ?>
		<?php  include('st-breadcrumb.php'); ?>
        <main id="page-success" class="inner-bottom-md">
        	<div class="container">
            	<div class="row">
                	<div class="col-md-12" >
						<h1>Successfull Registration, Please check your email-id for further process</h1>
                    </div>
                </div>
            </div>
        </main>
        <?php include('st-footer.php'); ?>
    </div>
    <?php include('st-javascript.php'); ?>
    <?php include('st-validator-js.php'); ?>	
</body>
</html>