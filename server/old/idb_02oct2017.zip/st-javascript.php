		<!-- For demo purposes – can be removed on production -->
      	<!--<div class="config open">
          <div class="config-options">
              <h4>Pages</h4>
              <ul class="list-unstyled animate-dropdown">
                  <li class="dropdown">
                      <button class="dropdown-toggle btn le-button btn-block" data-toggle="dropdown">View Pages</button>
                      <ul class="dropdown-menu">
                          <li><a href="index-2.html">Home-v1</a></li>
                          <li><a href="index-3.html">Home-v2</a></li>
                          <li><a href="category-grid.html">Category - Grid/List</a></li>
                          <li><a href="category-grid-2.html">Category 2 - Grid/List</a></li>
                          <li><a href="single-product.html">Single Product</a></li>
                          <li><a href="single-product-sidebar.html">Single Product with Sidebar</a></li>
                          <li><a href="cart.html">Shopping Cart</a></li>
                          <li><a href="checkout.html">Checkout</a></li>
                          <li><a href="about.html">About Us</a></li>
                          <li><a href="contact.html">Contact Us</a></li>
                          <li><a href="blog.html">Blog</a></li>
                          <li><a href="blog-fullwidth.html">Blog Full Width</a></li>
                          <li><a href="blog-post.html">Blog Post</a></li>
                          <li><a href="faq.html">FAQ</a></li>
                          <li><a href="terms.html">Terms &amp; Conditions</a></li>
                          <li><a href="authentication.html">Login/Register</a></li>
                          <li><a href="404.html">404</a></li>
                          <li><a href="wishlist.html">Wishlist</a></li>
                          <li><a href="compare.html">Product Comparison</a></li>
                          <li><a href="track-your-order.html">Track your Order</a></li>
                      </ul>
                  </li>
              </ul>
              <h4>Header Styles</h4>
              <ul class="list-unstyled">
                  <li><a href="index-2.html">Header 1</a></li>
                  <li><a href="index-3.html">Header 2</a></li>
              </ul>
              <h4>Colors</h4>
              <ul class="list-unstyled">
                  <li><a class="changecolor green-text" href="#" title="Green color">Green</a></li>
                  <li><a class="changecolor blue-text" href="#" title="Blue color">Blue</a></li>
                  <li><a class="changecolor red-text" href="#" title="Red color">Red</a></li>
                  <li><a class="changecolor orange-text" href="#" title="Orange color">Orange</a></li>
                  <li><a class="changecolor navy-text" href="#" title="Navy color">Navy</a></li>
                  <li><a class="changecolor dark-green-text" href="#" title="Darkgreen color">Dark Green</a></li>
              </ul>
          </div>
          <a class="show-theme-options" href="#"><i class="fa fa-wrench"></i></a>
      </div>-->
		<!-- For demo purposes – can be removed on production : End -->

		<!-- JavaScripts placed at the end of the document so the pages load faster -->
		<script src="<?php echo $BaseFolder; ?>/assets/js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/jquery-migrate-1.2.1.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/bootstrap-hover-dropdown.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/owl.carousel.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/css_browser_selector.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/echo.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/jquery.easing-1.3.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/bootstrap-slider.min.js"></script>
	    <script src="<?php echo $BaseFolder; ?>/assets/js/jquery.raty.min.js"></script>
	    <script src="<?php echo $BaseFolder; ?>/assets/js/jquery.prettyPhoto.min.js"></script>
	    <script src="<?php echo $BaseFolder; ?>/assets/js/jquery.customSelect.min.js"></script>
	    <script src="<?php echo $BaseFolder; ?>/assets/js/wow.min.js"></script>
		<script src="<?php echo $BaseFolder; ?>/assets/js/scripts.js"></script>
        <script src="<?php echo $BaseFolder; ?>/assets/js/bootstrap-datepicker.js"></script>
        

		<!-- For demo purposes – can be removed on production -->
		<!--<script src="switchstylesheet/switchstylesheet.js"></script>

		<script>
			$(document).ready(function(){
				$(".changecolor").switchstylesheet( { seperator:"color"} );
				$('.show-theme-options').click(function(){
					$(this).parent().toggleClass('open');
					return false;
				});
			});

			$(window).bind("load", function() {
			   $('.show-theme-options').delay(2000).trigger('click');
			});
		</script>-->
		<!-- For demo purposes – can be removed on production : End -->
