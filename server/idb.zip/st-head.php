	    <!-- Bootstrap Core CSS -->
	    <link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/bootstrap.min.css">

	    <!-- Customizable CSS -->
	    <link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/style.css">
	    <link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/colors/green.css">
	    <link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/owl.carousel.css">
		<link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/owl.transitions.css">
		<link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/animate.min.css">
         <!--Datepicker Satish 15092017-->
		<link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/datepicker.css" />
	    <!-- Fonts -->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>

		<!-- Icons/Glyphs -->
		<link rel="stylesheet" href="<?php echo $BaseFolder; ?>/assets/css/font-awesome.min.css">

		<!-- Favicon -->
		<link rel="shortcut icon" href="<?php echo $BaseFolder; ?>/assets/images/favicon.ico">
        
        <!--Datepicker Satish 15092017-->
    
		<!-- HTML5 elements and media queries Support for IE8 : HTML5 shim and Respond.js -->
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
