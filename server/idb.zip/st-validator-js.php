<script src="assets/js/plugins/validation/jquery.validate.min.js"></script>
<script src="assets/js/plugins/validation/additional-methods.min.js"></script>
<script src="assets/js/plugins/wizard/jquery.form.wizard.min.js"></script>
<script src="assets/js/eakroko.min.js"></script>
