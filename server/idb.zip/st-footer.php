<!-- ============================================================= FOOTER ============================================================= -->
            <footer id="footer" class="color-bg">
                <div class="container">
                    <div class="row no-margin widgets-row">
                        <div class="col-xs-12  col-sm-4 no-margin-left">
                           
                        </div><!-- /.col -->

                        <div class="col-xs-12 col-sm-4 ">
                            
                        </div><!-- /.col -->

                        <div class="col-xs-12 col-sm-4 ">
                            
                        </div><!-- /.col -->
                    </div><!-- /.widgets-row-->
                </div><!-- /.container -->

                

                <div class="link-list-row">
                    <div class="container no-padding">
                        <div class="col-xs-12 col-md-4 ">
                           
                            <div class="contact-info">
                                <div class="footer-logo">
                                   <img src="assets/images/logo_p.png" class="img-responsive"  />
                                </div><!-- /.footer-logo -->

                                <p class="regular-bold">Stepping Stone In Making Indian Generics Affordable At Cheapest Price And Doorstep Delivery To The Medical Fraternity.</p>

                               

                                <div class="social-icons">
                                    <h3>Get in touch</h3>
                                    <ul>
                                        <li><a href="javascript:void(0);" class="fa fa-facebook"></a></li>
                                        <li><a href="javascript:void(0);" class="fa fa-twitter"></a></li>
                                        <li><a href="javascript:void(0);" class="fa fa-pinterest"></a></li>
                                        <li><a href="javascript:void(0);" class="fa fa-linkedin"></a></li>
                                        <li><a href="javascript:void(0);" class="fa fa-stumbleupon"></a></li>
                                        <li><a href="javascript:void(0);" class="fa fa-dribbble"></a></li>
                                        <li><a href="javascript:void(0);" class="fa fa-vk"></a></li>
                                    </ul>
                                </div><!-- /.social-icons -->

                            </div>
                            
                        </div>

                        <div class="col-xs-12 col-md-8 no-margin">
                            <!-- ============================================================= LINKS FOOTER ============================================================= -->
                            <div class="link-widget">
                                <div class="widget">
                                    <h3>Know IDB</h3>
                                    <ul>
                                        <li><a href="javascript:void(0);">About IDB</a></li>
                                        <li><a href="javascript:void(0);">Contact Us</a></li>
                                        <li><a href="javascript:void(0);">Terms &amp; Conditions</a></li>
                                        <li><a href="javascript:void(0);">Disclaimer</a></li>
                                    </ul>
                                </div><!-- /.widget -->
                            </div><!-- /.link-widget -->


                            <div class="link-widget">
                                <div class="widget">
                                    <h3>Your Order</h3>
                                    <ul>
                                        <li><a href="javascript:void(0);">My Account</a></li>
                                        <li><a href="javascript:void(0);">Order History</a></li>
                                        <li><a href="javascript:void(0);">Track Order</a></li>
                                        <li><a href="javascript:void(0);">Login</a></li>
                                    </ul>
                                </div><!-- /.widget -->
                            </div><!-- /.link-widget -->

                            <div class="link-widget">
                                <div class="widget">
                                    <h3>Information</h3>
                                    <ul>
                                        <li><a href="javascript:void(0);">Vendor Policy</a></li>
                                        <li><a href="javascript:void(0);">Buyer Policy</a></li>
                                        <li><a href="javascript:void(0);">Shipping Policy</a></li>
                                        <li><a href="javascript:void(0);">FAQs</a></li>
                                    </ul>
                                </div><!-- /.widget -->
                            </div><!-- /.link-widget -->
                            
                        </div>
                    </div><!-- /.container -->
                </div><!-- /.link-list-row -->

                <div class="copyright-bar">
                    <div class="container">
                        <div class="col-xs-12 col-sm-6 no-margin">
                            <div class="copyright">
                                &copy; <a href="index.php">Indian Dava Bazar</a> - all rights reserved
                            </div><!-- /.copyright -->
                        </div>
                        <div class="col-xs-12 col-sm-6 no-margin">
                            <div class="payment-methods ">
                                <ul>
                                    <li><img alt="" src="assets/images/payments/payment-visa.png"></li>
                                    <li><img alt="" src="assets/images/payments/payment-master.png"></li>
                                    <li><img alt="" src="assets/images/payments/payment-paypal.png"></li>
                                    <li><img alt="" src="assets/images/payments/payment-skrill.png"></li>
                                </ul>
                            </div><!-- /.payment-methods -->
                        </div>
                    </div><!-- /.container -->
                </div><!-- /.copyright-bar -->
            </footer><!-- /#footer -->
<!-- ============================================================= FOOTER : END ============================================================= -->