var strings = new Array();
strings['cancel'] = 'Cancel';
strings['accept'] = 'Accept';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';