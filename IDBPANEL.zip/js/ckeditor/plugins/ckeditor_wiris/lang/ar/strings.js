var strings = new Array();
strings['cancel'] = 'إلغاء';
strings['accept'] = 'موافق';
strings['manual'] = 'الدليل';
strings['latex'] = 'LaTeX';