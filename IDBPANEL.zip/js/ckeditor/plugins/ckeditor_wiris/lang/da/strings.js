var strings = new Array();
strings['cancel'] = 'Annuller';
strings['accept'] = 'OK';
strings['manual'] = 'Brugervejledning';
strings['latex'] = 'LaTeX';