var strings = new Array();
strings['cancel'] = 'Vazgeç';
strings['accept'] = 'Tamam';
strings['manual'] = 'Kılavuz';
strings['latex'] = 'LaTeX';